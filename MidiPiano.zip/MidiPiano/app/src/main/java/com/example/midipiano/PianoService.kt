package com.example.midipiano

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.TextView
import android.widget.Toast

/**
 * 접근성 서비스: 화면 위에 ▶/■ 버튼을 띄우고,
 * MIDI 음을 건반 위치 터치로 바꿔서 보내 준다.
 */
class PianoService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: PianoService? = null
    }

    private class Group(val time: Long, val points: List<FloatArray>)

    private val handler = Handler(Looper.getMainLooper())
    private val token = Any()
    private lateinit var wm: WindowManager

    private var button: TextView? = null
    private var guide: View? = null

    private var groups: List<Group> = emptyList()
    private var idx = 0
    private var t0 = 0L

    var playing = false
        private set

    // ---------------- 서비스 수명주기 ----------------

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        showButton()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {
        stopPlay()
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        stopPlay()
        hideGuide()
        hideButton()
        instance = null
        return super.onUnbind(intent)
    }

    // ---------------- 연주 ----------------

    fun togglePlay() {
        if (playing) stopPlay() else startPlay()
    }

    private fun startPlay() {
        val midi = Shared.midi
        if (midi == null) {
            toast("앱에서 MIDI 파일을 먼저 선택하세요")
            return
        }
        stopPlay()
        groups = buildGroups(midi)
        idx = 0
        t0 = SystemClock.uptimeMillis() + 300
        playing = true
        updateButton()
        scheduleNext()
    }

    fun stopPlay() {
        playing = false
        handler.removeCallbacksAndMessages(token)
        updateButton()
    }

    /** 25ms 안에 같이 울리는 음은 한 번의 제스처(화음)로 묶는다. */
    private fun buildGroups(m: MidiData): List<Group> {
        val c = Cfg(this)
        val (w, h) = screen()
        val speed = maxOf(c.speed, 0.1f)
        val out = ArrayList<Group>()
        var gTime = Long.MIN_VALUE
        var cur: ArrayList<FloatArray>? = null
        val seen = HashSet<Int>()
        for (n in m.notes) {
            val t = (n.ms / speed).toLong()
            val note = KeyLayout.fit(n.note + c.transpose)
            if (cur == null || t - gTime > 25) {
                val list = ArrayList<FloatArray>()
                cur = list
                seen.clear()
                gTime = t
                out.add(Group(t, list))
            }
            if (seen.add(note)) cur?.add(KeyLayout.position(note, c, w, h))
        }
        return out
    }

    private fun scheduleNext() {
        if (!playing) return
        if (idx >= groups.size) {
            stopPlay()
            toast("연주 끝")
            return
        }
        val g = groups[idx]
        handler.postAtTime(Runnable {
            if (!playing) return@Runnable
            tap(g)
            idx++
            scheduleNext()
        }, token, t0 + g.time)
    }

    private fun tap(g: Group) {
        val b = GestureDescription.Builder()
        val max = GestureDescription.getMaxStrokeCount()
        for (pt in g.points.take(max)) {
            val p = Path()
            p.moveTo(pt[0], pt[1])
            p.lineTo(pt[0] + 1f, pt[1])
            b.addStroke(GestureDescription.StrokeDescription(p, 0L, 20L))
        }
        try {
            dispatchGesture(b.build(), null, null)
        } catch (_: Exception) {
        }
    }

    // ---------------- 화면 위 시작/정지 버튼 ----------------

    private fun showButton() {
        if (button != null) return
        val size = (56 * resources.displayMetrics.density).toInt()
        val tv = TextView(this).apply {
            text = "▶"
            textSize = 20f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#CC2E7D32"))
            }
        }
        val lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 24
            y = 120
        }

        var startX = 0
        var startY = 0
        var downX = 0f
        var downY = 0f
        var moved = false
        var longFired = false
        val longPress = Runnable {
            longFired = true
            toggleGuide()
        }

        tv.setOnTouchListener { _, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = lp.x
                    startY = lp.y
                    downX = ev.rawX
                    downY = ev.rawY
                    moved = false
                    longFired = false
                    handler.postDelayed(longPress, 700)
                }
                MotionEvent.ACTION_MOVE -> {
                    val mx = ev.rawX - downX
                    val my = ev.rawY - downY
                    if (moved || Math.abs(mx) > 12 || Math.abs(my) > 12) {
                        moved = true
                        handler.removeCallbacks(longPress)
                        lp.x = startX + mx.toInt()
                        lp.y = startY + my.toInt()
                        wm.updateViewLayout(tv, lp)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    handler.removeCallbacks(longPress)
                    if (!moved && !longFired) togglePlay()
                }
                MotionEvent.ACTION_CANCEL -> handler.removeCallbacks(longPress)
            }
            true
        }
        wm.addView(tv, lp)
        button = tv
    }

    private fun hideButton() {
        button?.let {
            try {
                wm.removeView(it)
            } catch (_: Exception) {
            }
        }
        button = null
    }

    private fun updateButton() {
        val tv = button ?: return
        tv.text = if (playing) "■" else "▶"
        (tv.background as? GradientDrawable)?.setColor(
            Color.parseColor(if (playing) "#CCC62828" else "#CC2E7D32")
        )
    }

    // ---------------- 건반 위치 미리보기 ----------------

    /** 건반 터치 위치를 점으로 보여 준다(흰 건반 초록, 검은 건반 빨강). 다시 부르면 숨김. */
    fun toggleGuide() {
        if (guide != null) {
            hideGuide()
            return
        }
        val (w, h) = screen()
        val v = GuideView()
        val lp = WindowManager.LayoutParams(
            w, h,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }
        wm.addView(v, lp)
        guide = v
    }

    private fun hideGuide() {
        guide?.let {
            try {
                wm.removeView(it)
            } catch (_: Exception) {
            }
        }
        guide = null
    }

    private inner class GuideView : View(this@PianoService) {
        private val whitePaint = Paint().apply { color = Color.argb(220, 0, 200, 80) }
        private val blackPaint = Paint().apply { color = Color.argb(220, 230, 40, 40) }

        override fun onDraw(canvas: Canvas) {
            val c = Cfg(this@PianoService)
            for (n in KeyLayout.LOW..KeyLayout.HIGH) {
                val p = KeyLayout.position(n, c, width, height)
                canvas.drawCircle(p[0], p[1], 9f, if (KeyLayout.isBlack(n)) blackPaint else whitePaint)
            }
            postInvalidateDelayed(400) // 슬라이더를 움직이면 바로 반영
        }
    }

    // ---------------- 도우미 ----------------

    private fun screen(): Pair<Int, Int> {
        return if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.currentWindowMetrics.bounds
            b.width() to b.height()
        } else {
            val m = DisplayMetrics()
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealMetrics(m)
            m.widthPixels to m.heightPixels
        }
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }
}
