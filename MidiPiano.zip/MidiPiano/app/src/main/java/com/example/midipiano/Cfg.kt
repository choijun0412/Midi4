package com.example.midipiano

import android.content.Context

/** 설정 화면의 슬라이더 값 (SharedPreferences) */
class Cfg(ctx: Context) {
    private val p = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun v(key: String) = p.getInt(key, DEFAULTS.getValue(key))

    val left get() = v("left") / 100f        // 건반 왼쪽 끝 (화면 너비 %)
    val right get() = v("right") / 100f      // 건반 오른쪽 끝
    val whiteY get() = v("whiteY") / 100f    // 흰 건반 터치 높이 (화면 높이 %)
    val blackY get() = v("blackY") / 100f    // 검은 건반 터치 높이
    val whiteCount get() = v("whiteCount")   // 화면에 보이는 흰 건반 개수
    val transpose get() = v("transpose")     // 반음 이동
    val speed get() = v("speed") / 100f      // 속도 배율

    companion object {
        const val PREFS = "cfg"
        val DEFAULTS = mapOf(
            "left" to 5,
            "right" to 95,
            "whiteY" to 85,
            "blackY" to 65,
            "whiteCount" to 36,
            "transpose" to 0,
            "speed" to 100
        )
    }
}

/** MIDI 노트 번호(C2=36 ~ C7=96, Virtual Piano 61키) -> 화면 좌표 */
object KeyLayout {
    const val LOW = 36
    const val HIGH = 96
    private val WHITE_IDX = intArrayOf(0, 0, 1, 1, 2, 3, 3, 4, 4, 5, 5, 6)
    private val BLACK = booleanArrayOf(false, true, false, true, false, false, true, false, true, false, true, false)

    fun fit(note: Int): Int {
        var n = note
        while (n < LOW) n += 12
        while (n > HIGH) n -= 12
        return n
    }

    fun isBlack(note: Int): Boolean = BLACK[(fit(note) - LOW) % 12]

    /** @return [x, y] (픽셀) */
    fun position(note: Int, c: Cfg, w: Int, h: Int): FloatArray {
        val n = fit(note)
        val rel = n - LOW
        val idx = (rel / 12) * 7 + WHITE_IDX[rel % 12]
        val keyW = (c.right - c.left) * w / c.whiteCount
        val x0 = c.left * w
        return if (BLACK[rel % 12]) {
            floatArrayOf(x0 + (idx + 1) * keyW, c.blackY * h)
        } else {
            floatArrayOf(x0 + (idx + 0.5f) * keyW, c.whiteY * h)
        }
    }
}
