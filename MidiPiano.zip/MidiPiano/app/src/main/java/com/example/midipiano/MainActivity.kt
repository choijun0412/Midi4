package com.example.midipiano

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var fileInfo: TextView
    private lateinit var svcInfo: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val dp = resources.displayMetrics.density
        val pad = (16 * dp).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        setContentView(ScrollView(this).apply { addView(root) })

        root.addView(TextView(this).apply {
            text = "MIDI → 로블록스 Virtual Piano"
            textSize = 20f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        })

        svcInfo = TextView(this).apply { setPadding(0, pad / 2, 0, pad / 2) }
        root.addView(svcInfo)
        root.addView(button("① 접근성 설정 열기") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })

        root.addView(button("② MIDI 파일 선택") {
            val i = Intent(Intent.ACTION_GET_CONTENT).apply {
                type = "*/*"
                addCategory(Intent.CATEGORY_OPENABLE)
            }
            startActivityForResult(Intent.createChooser(i, "MIDI 파일 선택"), REQ_MIDI)
        })
        fileInfo = TextView(this).apply {
            text = "선택된 파일 없음"
            setPadding(0, pad / 2, 0, pad / 2)
        }
        root.addView(fileInfo)

        root.addView(section("③ 건반 위치 맞추기"))
        slider(root, "건반 왼쪽 끝 (화면 너비 %)", "left", 0, 50) { "$it%" }
        slider(root, "건반 오른쪽 끝 (화면 너비 %)", "right", 50, 100) { "$it%" }
        slider(root, "흰 건반 터치 높이 (화면 높이 %)", "whiteY", 40, 100) { "$it%" }
        slider(root, "검은 건반 터치 높이 (화면 높이 %)", "blackY", 20, 100) { "$it%" }
        slider(root, "화면에 보이는 흰 건반 개수", "whiteCount", 14, 52) { "${it}개" }
        root.addView(button("건반 위치 점 보기 / 숨기기") {
            val s = PianoService.instance
            if (s == null) toast("먼저 접근성 서비스를 켜세요") else s.toggleGuide()
        })

        root.addView(section("④ 연주 설정"))
        slider(root, "음높이 이동 (반음)", "transpose", -24, 24) { (if (it > 0) "+" else "") + it }
        slider(root, "속도 배율", "speed", 25, 300) { String.format("%.2f배", it / 100f) }

        root.addView(TextView(this).apply {
            setPadding(0, pad, 0, 0)
            text = "사용법\n" +
                "1) 접근성에서 'MIDI 피아노'를 켜면 화면에 초록 ▶ 버튼이 떠요.\n" +
                "2) MIDI 파일을 고르고, 로블록스 Virtual Piano를 가로 화면으로 열어요.\n" +
                "3) ▶ 버튼을 누르면 시작, 빨간 ■ 버튼을 누르면 멈춰요. 버튼은 끌어서 옮길 수 있고, 길게 누르면 건반 위치 점이 켜지고 꺼져요.\n" +
                "4) 점이 실제 건반 위에 오도록 ③의 슬라이더를 조절하세요. (초록=흰 건반, 빨강=검은 건반)"
        })
    }

    override fun onResume() {
        super.onResume()
        svcInfo.text = if (PianoService.instance != null) {
            "접근성 서비스: 켜짐 (화면의 ▶ 버튼으로 시작/정지)"
        } else {
            "접근성 서비스: 꺼짐 — 설정 > 접근성 > 설치된 앱 > 'MIDI 피아노'를 켜세요"
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_MIDI || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        try {
            val bytes = contentResolver.openInputStream(uri)!!.use { it.readBytes() }
            val midi = MidiParser.parse(bytes)
            Shared.midi = midi
            Shared.name = displayName(uri)
            val sec = midi.lengthMs / 1000
            fileInfo.text = "${Shared.name}\n음 ${midi.notes.size}개, 길이 ${sec / 60}분 ${sec % 60}초"
        } catch (e: Exception) {
            toast("불러오기 실패: ${e.message}")
        }
    }

    // ---------------- 도우미 ----------------

    private fun displayName(uri: Uri): String {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) return c.getString(0)
        }
        return uri.lastPathSegment ?: "midi"
    }

    private fun button(label: String, onClick: () -> Unit): Button =
        Button(this).apply {
            text = label
            setOnClickListener { onClick() }
        }

    private fun section(label: String): TextView =
        TextView(this).apply {
            text = label
            textSize = 16f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, (16 * resources.displayMetrics.density).toInt(), 0, 0)
        }

    private fun slider(
        parent: LinearLayout, label: String, key: String,
        min: Int, max: Int, fmt: (Int) -> String
    ) {
        val prefs = getSharedPreferences(Cfg.PREFS, Context.MODE_PRIVATE)
        val cur = prefs.getInt(key, Cfg.DEFAULTS.getValue(key)).coerceIn(min, max)
        val tv = TextView(this).apply { text = "$label: ${fmt(cur)}" }
        val sb = SeekBar(this).apply {
            this.max = max - min
            progress = cur - min
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    val v = p + min
                    prefs.edit().putInt(key, v).apply()
                    tv.text = "$label: ${fmt(v)}"
                }

                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        parent.addView(tv)
        parent.addView(sb)
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    companion object {
        private const val REQ_MIDI = 1
    }
}
